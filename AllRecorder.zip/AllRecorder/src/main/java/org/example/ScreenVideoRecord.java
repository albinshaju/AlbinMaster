package org.example;

import org.jcodec.api.awt.AWTSequenceEncoder;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import java.awt.Rectangle;
import java.awt.Toolkit;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ScreenVideoRecord {
    boolean NeedToStop = false;
    int ForceStopTimeInSeconds=10;
    int ForceStopTimeInMilliSecond = ForceStopTimeInSeconds*1000;
    static int SleepMilliSeconds1 = 10000;
    String ScreenSize="";
    String ScreenRec="";
    String FileName ="screen-recording";// Output file name
    String FileFormat ="mp4";
    String FilePath ="F:\\Softwares\\Downloads\\";
    String FileNamewithFormat =FileName + "." + FileFormat;
    String FullFilePath = "";

    int ScreenWidth = 0;
    int ScreenHeight = 0;
    int FrameRate = 5; // Number of frames per second
    String Delim1 = "|";

    public static void main(String[] args) {
        try {
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            Robot robot = new Robot();
            ScreenVideoRecord RecArea = new ScreenVideoRecord(screenRect, robot);
            RecArea.startRecording();

            // Record for 10 seconds
            Thread.sleep(SleepMilliSeconds1);

            RecArea.stopRecording();
        } catch (AWTException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private Rectangle captureArea;
    private Robot robot;

    public ScreenVideoRecord(Rectangle captureArea, Robot robot) {
        this.captureArea = captureArea;
        this.robot = robot;
    }

    public void startRecording() {
        try {
            FullFilePath = FilePath + FileName + TimeForFileGetter() + "." + FileFormat;
            File outputFile = new File(FullFilePath);
            AWTSequenceEncoder encoder =
                    AWTSequenceEncoder.createSequenceEncoder(outputFile,FrameRate );
            //AWTSequenceEncoder.createSequenceEncoder(outputFile, 24 / 8);

            long startTime = System.currentTimeMillis();

            while (true) {
                BufferedImage image = robot.createScreenCapture(captureArea);
                encoder.encodeImage(image);

                long elapsedTime = System.currentTimeMillis() - startTime;
                if (elapsedTime >= ForceStopTimeInMilliSecond) { // Stop recording after 10 Seconds
                    break;
                }
            }

            encoder.finish();
            //NIOUtils.closeQuietly(encoder);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void stopRecording() {
        // Implement the logic to stop the recording
        try {
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public String TimeForFileGetter() {
        String TimeFile="";
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd hh mm ss a");
            Calendar now = Calendar.getInstance();
            TimeFile=formatter.format(now.getTime());
            TimeFile = "_"+TimeFile.replaceAll(" ","_");
            return TimeFile;
        } catch (Exception e) {
            e.printStackTrace();
            return TimeFile;
        }
    }


}
