package org.example;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
public class ScreenWindow {

    boolean CheckE = true;
	/*private static String Path ="C:\\Users\\258411\\Desktop\\Screenshots\\";
	private static int timeframe = 3000;*/

    private static String Path ="";
    private static int timeframe = 3000;

    ScreenWindow()
    {

        JFrame f=new JFrame("Screen Capture");
        //f.setContentPane(new JLabel(new ImageIcon("C:\\Users\\258411\\Desktop\\Java\\2.png")));

        Font font = new Font("Lucida Sans", Font.BOLD,12);
        f.setFont(font);

        //ImageIcon img = new ImageIcon("C:\\Users\\258411\\Desktop\\Java\\S1.png");
        //f.setIconImage(img.getImage());

        JLabel label1 = new JLabel("Screen Capture Path");
        label1.setBounds(10,5,150,70);

        label1.setFont(font);
        label1.setForeground(Color.BLACK);


        JLabel label2 = new JLabel("Time Frame");
        label2.setBounds(10,35,150,70);

        label2.setFont(font);
        label2.setForeground(Color.BLACK);

        JTextField Tx1 = new JTextField();
        Tx1.setBounds(150,30,300,20);

        Tx1.setFont(font);
        Tx1.setForeground(Color.BLUE);

        JTextField Tx2 = new JTextField();
        Tx2.setBounds(150,60,300,20);

        Tx2.setFont(font);
        Tx2.setForeground(Color.BLUE);

        JButton b1=new JButton("Start Capture", new ImageIcon("play.png"));
        b1.setBounds(150,100,140,40);

        b1.setFont(font);
        b1.setForeground(Color.GREEN);


        JButton b2=new JButton("Stop Capture", new ImageIcon("play.png"));
        b2.setBounds(300,100,140,40);

        b2.setFont(font);
        b2.setForeground(Color.RED);

        JButton b3=new JButton("Capture Now", new ImageIcon("play.png"));
        b3.setBounds(225,150,140,40);

        b3.setFont(font);
        b3.setForeground(Color.BLUE);

        f.add(b1);
        f.add(b2);
        f.add(b3);

        f.add(label1);
        f.add(label2);

        f.add(Tx1);
        f.add(Tx2);


        f.setSize(500,300);
        f.setLayout(null);

        f.setLocation(450, 300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if(!Tx1.getText().contentEquals("") && !Tx2.getText().contentEquals(""))
                    {
                        Path = Tx1.getText();
                        timeframe=Integer.valueOf(Tx2.getText());
                        StartC(Path,timeframe);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"UNABLE TO FETCH DETAILS","ALERT",JOptionPane.WARNING_MESSAGE);
                    }

                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });


        b2.addActionListener(new ActionListener() {
            @SuppressWarnings("static-access")
            public void actionPerformed(ActionEvent e) {
                ImageCapture obj1 = new ImageCapture();
                obj1.CheckE = false;
                JOptionPane.showMessageDialog(null,"SCREEN CAPTURING PROCESS FINISHED","ALERT",JOptionPane.WARNING_MESSAGE);
            }
        });

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if(!Tx1.getText().contentEquals(""))
                    {
                        Path = Tx1.getText();
                        StartInd(Path);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"UNABLE TO FETCH DETAILS","ALERT",JOptionPane.WARNING_MESSAGE);
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });


    }

    public static void main(String[] args)
    {
        new ScreenWindow();
    }

    @SuppressWarnings("static-access")
    public void StartC(String Path,int timef) throws Exception
    {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ImageCapture obj = new ImageCapture();
                while(obj.CheckE)
                {
                    try
                    {
                        obj.robo(Path);
                        Thread.sleep(timef);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();


    }

    public void StartInd(String Path) throws Exception
    {
        IndivudualImage obj2 = new IndivudualImage();
        obj2.IndCapt(Path);
    }
}
