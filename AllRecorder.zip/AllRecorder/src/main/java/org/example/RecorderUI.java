package org.example;

import org.jcodec.api.awt.AWTSequenceEncoder;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Objects;


public class RecorderUI {
    private JPanel JPanelMain;
    private JLabel JL_RS;
    private JLabel JL_RSValue;
    private JLabel JL_Timer;
    private JCheckBox JCB_DelayStart;
    private JTextField JTF_DSValue;
    private JButton JB_StartRec;
    private JButton JB_StopRec;
    private JButton JB_ResetRec;
    private JTextArea JTA_LocBrowseVal;
    private JButton JB_Browse;
    private JRadioButton JRB_Image;
    private JRadioButton JRB_Video;
    private JTextField JTF_VFrameRateVal;
    private JLabel JL_VFrameRate;
    private JTextField JTF_ImgTFVal;
    private JTextField JTF_RecordFilePrefixVal;
    private JLabel JL_ImgTF;
    private JLabel JL_RecordFilePrefix;
    private JTextField JTF_MaxVRecVal;
    private JCheckBox JCB_MaxVRec;
    private JLabel JL_RecType;



    private int elapsedTime;
    private Timer timer;
    private String StartRecStatus ="In-Progress";
    private String StopRecStatus ="Stopped";
    private String ResetStatus ="Not Started";
    private String TimerVal="00:00:00";
    private String DSVal="5";
    private String ImgTFVal="3";
    private String VFrameRateVal="30";
    private int JFrameSizeW=750;
    private int JFrameSizeH=400;
    private String MaxVRecVal="10";
    private String LocBrowseVal="Browse the path to record....";
    private String BrowseCancel="Browse Option Cancelled. Please retry if you want!!!";
    private String JFrameTitle="All Recorder";

    boolean NeedToStop = false;
    int ForceStopTimeInSeconds=10;
    int ForceStopTimeInMilliSecond = ForceStopTimeInSeconds*1000;
    static int SleepMilliSeconds1 = 10000;
    String ScreenSize="";
    String ScreenRec="";
    String FileName ="screen-recording";// Output file name
    String VFileFormat ="mp4";
    String FilePath ="F:\\Softwares\\Downloads\\";
    String FileNamewithFormat =FileName + "." + VFileFormat;
    String FullFilePath = "";

    int ScreenWidth = 0;
    int ScreenHeight = 0;
    int FrameRate = 30; // Number of frames per second
    String Delim1 = "|";
    String ImageFormat ="jpg";

    public boolean IsImageCapture = false;
    public boolean IsVideoCapture = false;
    public final long serialVersionUID = 1L;

    private String Path ="";
    private String timeframe = "3";

    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd hh mm ss a");


    //ImageIcon Logo = new ImageIcon(getClass().getResource(".//res//Recording3.jpg"));

    String JPanelColor1 = "#F0F8FF";
    String JTAColor1 = "#7393B3";


    private Rectangle captureArea;
    private Robot robot;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private ButtonGradient buttonGradient1;
    private ButtonGradient buttonGradient2;
    // End of variables declaration//GEN-END:variables

    public static void main( String[] arg ) {
        RecorderUI R = new RecorderUI();

    }

    public RecorderUI() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    //System.out.println("Nimbus look and feel available, Setting it.");
                    break;
                }
            }



        } catch (Exception e) {
            // If Nimbus is not available, you can set the GUI to another look and feel.
            System.err.println("Nimbus look and feel not available, using default.");
        }

        // Run the form creation on the Event Dispatch Thread
        SwingUtilities.invokeLater(this::UICreateV1);
        /*SwingUtilities.invokeLater(() -> {
            //Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);

            JB_Browse.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            JB_StopRec.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            JB_StartRec.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            JB_ResetRec.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            UICreateV1();
        });*/

        //Action Listeners Based on selection
        JRB_Image.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EnableDisableFirstLoad();
            }
        });

        JRB_Video.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EnableDisableFirstLoad();
                if(IsCheckBoxSelected(JCB_DelayStart))
                {
                    JTF_DSValue.setEnabled(true);
                }
                else
                {
                    JTF_DSValue.setEnabled(false);
                }
                if(IsCheckBoxSelected(JCB_MaxVRec))
                {
                    JTF_MaxVRecVal.setEnabled(true);
                }
                else
                {
                    JTF_MaxVRecVal.setEnabled(false);
                }
            }
        });

        JCB_DelayStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(IsCheckBoxSelected(JCB_DelayStart))
                {
                    JTF_DSValue.setEnabled(true);
                }
                else
                {
                    JTF_DSValue.setEnabled(false);
                }

            }
        });

        JCB_MaxVRec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(IsCheckBoxSelected(JCB_MaxVRec))
                {
                    JTF_MaxVRecVal.setEnabled(true);
                }
                else
                {
                    JTF_MaxVRecVal.setEnabled(false);
                }
            }
        });

        JB_Browse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Call Browse Click Option
                ClickBrowsePath(e);
            }
        });

        JB_StartRec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Mandatory Checks
                boolean isMandy = MandatoryFieldChecks();
                if(isMandy) {
                    timer.start();
                    JL_RSValue.setText(StartRecStatus);
                    EnableDisableStartRecordingButtons();
                    TypeOfRecStartOptions();
                }
                else
                {
                    MandatoryFieldMissingMessageBox();
                }
            }
        });

        JB_StopRec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timer.stop();
                JL_RSValue.setText(StopRecStatus);
                TypeOfRecStopOptions();
                EnableDisableStopRecordingButtons();
            }
        });

        JB_ResetRec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timer.stop();
                elapsedTime = 0;
                //JL_RSValue.setText(ResetStatus);
                LoadingDefaultUIValueSettings();
                updateTimeLabel();
            }
        });

        JB_Browse.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JB_Browse.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
        });

    }


    public void UICreateV1() {
        try {


            JFrame JF = new JFrame(JFrameTitle);
            JF.setDefaultCloseOperation(JF.EXIT_ON_CLOSE );
            JPanelMain.setBackground(Color.decode(JPanelColor1));

            JB_Browse.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));




            ImageIcon icon = new ImageIcon("..\\AllRecorder\\src\\res\\Recording3.jpg"); // Replace with your image path
            JF.setIconImage(icon.getImage());

            //Already added by creating UI
            //JPanelMain.add(JL_RS);
            //JPanelMain.add(JL_RSValue);
            //JPanelMain.add(JL_Timer);

            JF.getContentPane().add(JPanelMain);
            JF.setSize( JFrameSizeW, JFrameSizeH );
            FontSetting("Segoe UI",12,JF);
            //JF.setLayout(new GridLayout(2, 1));
            JF.setLocationRelativeTo(JPanelMain);
            //JF.setLocationRelativeTo(null);

            //Call Browse Click Option
            //ClickBrowsePath();

            //Default Value Settings:
            LoadingDefaultUIValueSettings();

            //Maximazie Frame Disabled
            JF.setResizable(false);



            EnableDisableFirstLoad();

            JF.setVisible(true);

            TimerSet();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LoadingDefaultUIValueSettings() {
        JL_RSValue.setText(ResetStatus);
        JL_Timer.setText(TimerVal);
        JCB_DelayStart.setSelected(false);

        NumericTextFields(JTF_DSValue);
        NumericTextFields(JTF_ImgTFVal);
        NumericTextFields(JTF_VFrameRateVal);
        NumericTextFields(JTF_MaxVRecVal);

        DisableCopyPasteInTextField(JTF_DSValue,DSVal);
        DisableCopyPasteInTextField(JTF_ImgTFVal,ImgTFVal);
        DisableCopyPasteInTextField(JTF_VFrameRateVal,VFrameRateVal);
        DisableCopyPasteInTextField(JTF_MaxVRecVal,MaxVRecVal);

        //JTF_DSValue.setText(DSVal);
        //JTF_ImgTFVal.setText(ImgTFVal);
        //JTF_VFrameRateVal.setText(VFrameRateVal);
        JTF_RecordFilePrefixVal.setText("");

        RadioButtonSettingsDefault(JRB_Image,JRB_Video);
        JTA_LocBrowseVal.setBorder(BorderFactory.createLineBorder(Color.decode(JTAColor1)));
        JTA_LocBrowseVal.setText(LocBrowseVal);
    }

    public void ScreenVideoRecordAreaSet(Rectangle captureArea, Robot robot) {
        this.captureArea = captureArea;
        this.robot = robot;
    }

    public void ScreenVideoRecordAreaMain(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                    try {
                        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                        Robot robot = new Robot();
                        ScreenVideoRecordAreaSet(screenRect, robot);
                        StartVideoRecording();

                        //Record for 10 seconds
                        //Thread.sleep(SleepMilliSeconds1);

                        StopVideoRecording();
                    }
                    catch (Exception e) {
                    //catch (AWTException | InterruptedException e) {
                        e.printStackTrace();
                    }
            }
        }).start();
    }

    public void StartVideoRecording() {
        try {

            FilePath = JTA_LocBrowseVal.getText();
            FilePath = FilePath + "\\";
            timeframe = JTF_VFrameRateVal.getText();
            FrameRate = Integer.parseInt(timeframe);
            String FileName = JTF_RecordFilePrefixVal.getText();
            FullFilePath = FilePath + FileName + TimeForFileGetter() + "." + VFileFormat;

            File outputFile = new File(FullFilePath);
            IsVideoCapture=true;

            String isDSValue = CheckBoxMaxVideoRecOption(JCB_DelayStart,JTF_DSValue,"Delay Record Time");

            if(isDSValue.contentEquals(""))
            {

            }
            else
            {
                try {
                    Thread.sleep(Integer.parseInt((isDSValue))* 1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

            AWTSequenceEncoder encoder = AWTSequenceEncoder.createSequenceEncoder(outputFile,FrameRate);

            //AWTSequenceEncoder.createSequenceEncoder(outputFile, 24 / 8);

            long startTime = System.currentTimeMillis();

            //Max Video Rec Check Box and Value
            String isMaxRec = CheckBoxMaxVideoRecOption(JCB_MaxVRec,JTF_MaxVRecVal,"Maximum Recording Time");

            int c1 = 0;
            while(IsVideoCapture) {
                BufferedImage image = robot.createScreenCapture(captureArea);
                encoder.encodeImage(image);
                c1 =c1 +1;
                System.out.println("Video Encoding : "+c1);

                long elapsedTime1 = System.currentTimeMillis() - startTime;

                if(!isMaxRec.contentEquals(""))
                {
                    ForceStopTimeInMilliSecond=Integer.parseInt(isMaxRec)*1000;

                    // Stop recording after 10 Seconds
                    if (elapsedTime1 >= ForceStopTimeInMilliSecond) {
                        IsVideoCapture = false;
                        System.out.println("Video Encoding Exceeded "+isMaxRec);
                        break;
                    }
                    else
                    {
                        //Stop Button clicking will set the flag as false
                    }
                }
                else
                {
                    //Set Flag to Stop
                    //Stop Button clicking will set the flag as false
                }


            }

            encoder.finish();
            //NIOUtils.closeQuietly(encoder);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void StopVideoRecording() {
        // Implement the logic to stop the recording
        try {
            IsVideoCapture = false;
            String isMaxRec = CheckBoxMaxVideoRecOption(JCB_MaxVRec,JTF_MaxVRecVal,"Maximum Recording Time");
            System.out.println("Video Encoding Stop Function");
            if(!isMaxRec.contentEquals("")) {
                //JB_StopRec.doClick();
                timer.stop();
                JL_RSValue.setText(StopRecStatus);
                EnableDisableStopRecordingButtons();
            }
            JOptionPane.showMessageDialog(null,"Video Capturing Finished","Process Completion",JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SecondsToMill(int Seconds) {
        int MillSec = Seconds*1000;
    }

    public void TimerSet() {

        //JB_StartRec.addActionListener(this);
        //JB_StopRec.addActionListener(this);
        //JB_ResetRec.addActionListener(this);

        // Set up the timer
        timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                elapsedTime += 1000;
                updateTimeLabel();
            }
        });
    }

/*    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == JB_StartRec) {
            //Mandatory Checks
            boolean isMandy = MandatoryFieldChecks();
            if(isMandy) {
                timer.start();
                JL_RSValue.setText(StartRecStatus);
                EnableDisableStartRecordingButtons();
                TypeOfRecStartOptions();
            }
            else
            {
                MandatoryFieldMissingMessageBox();
            }
        } else if (e.getSource() == JB_StopRec) {
            timer.stop();
            JL_RSValue.setText(StopRecStatus);
            TypeOfRecStopOptions();
            EnableDisableStopRecordingButtons();
        } else if (e.getSource() == JB_ResetRec) {
            timer.stop();
            elapsedTime = 0;
            //JL_RSValue.setText(ResetStatus);
            LoadingDefaultUIValueSettings();
            updateTimeLabel();
        }
    }*/

    public void updateTimeLabel() {
        int hours = elapsedTime / 3600000;
        int minutes = (elapsedTime % 3600000) / 60000;
        int seconds = (elapsedTime % 60000) / 1000;
        String time = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        JL_Timer.setText(time);
    }

    public void NumericTextFields(JTextField JTF) {
        JTF.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) ||
                        (c == KeyEvent.VK_BACK_SPACE) ||
                        (c == KeyEvent.VK_DELETE))) {
                    e.consume();
                }
            }
        });
    }

    public void DisableCopyPasteInTextField(JTextField JTF, String DefaultVal) {
        JTF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JTF.setTransferHandler(null);
                String JTFText = JTF.getText();
                if (!JTFText.matches("[0-9]+"))
                {
                    JTF.setText(DefaultVal);
                }
            }
        });
    }

    public void RadioButtonSettingsDefault(JRadioButton J1,JRadioButton J2) {
        ButtonGroup G = new ButtonGroup();
        G.add(J1);
        G.add(J2);
        J1.setSelected(true);
        //if(J1.isSelected()) to check if RB is selected or not
    }

    public boolean IsRadioButtonSelected(JRadioButton RB) {
        return RB.isSelected();
    }

    public boolean IsCheckBoxSelected(JCheckBox CB ) {
        return CB.isSelected();
    }

    public boolean NumericValueCheck(String str)
    {
        return str != null && str.matches("\\d+");
    }

    public boolean FilePathExistance(String FolderPath)
    {
        boolean isPathV=false;
        Path P = Paths.get(FolderPath);
        if(Files.exists(P) && Files.isDirectory(P))
        {
            System.out.println("Selected Location is Available for output storage");
            isPathV=true;
        }
        else
        {
            System.out.println("Selected Location is not Available for output storage");
            isPathV=false;
            //MandatoryFieldMissingMessageBox();
        }
        return isPathV;
    }

    public boolean CheckBoxAndValueValidation(JCheckBox JCB, JTextField JTF, String FieldDesc)
    {
        Boolean isSuccess=false;
        Boolean CheckBoxSelected=IsCheckBoxSelected(JCB);

        if(CheckBoxSelected)
        {
            String TempVal = JTF.getText();
            if(TempVal.equals(""))
            {
                System.out.println(FieldDesc+" CheckBox Selected. But the value is selected as empty. Please add " + FieldDesc);
                isSuccess=false;
                //MandatoryFieldMissingMessageBox();
            }
            else
            {
                if(!NumericValueCheck(TempVal))
                {
                    System.out.println(FieldDesc+" CheckBox Selected. Non-Numeric Value Found. Please add " + FieldDesc + " in numeric");
                    isSuccess=false;
                    //MandatoryFieldMissingMessageBox();
                }
                else
                {
                    System.out.println(FieldDesc+" CheckBox Selected. Value Looks Fine");
                    isSuccess=true;
                }
            }
        }
        else
        {
            System.out.println(FieldDesc+" CheckBox Not Selected.");
            isSuccess=true;
        }
        return isSuccess;
    }

    public String CheckBoxMaxVideoRecOption(JCheckBox JCB, JTextField JTF, String FieldDesc)
    {
        Boolean CheckBoxSelected=IsCheckBoxSelected(JCB);
        String TempVal="";

        if(CheckBoxSelected)
        {
            TempVal = JTF.getText();
        }
        else
        {
            TempVal="";
        }
        return TempVal;
    }

    public void MandatoryFieldMissingMessageBox()
    {
        JOptionPane.showMessageDialog(null, "There are some Mandatory fields missing or incorrect. Please correct and try again",
                "Mandatory Fields Missing or Incorrect", JOptionPane.ERROR_MESSAGE);
        //System.exit(0);
    }

    public boolean RadioButtonAndValueValidation(JRadioButton JRB,JTextField JTF, String FieldDesc)
    {
        Boolean isSuccess=false;
        Boolean RadioButtonSelected=IsRadioButtonSelected(JRB);

        if(RadioButtonSelected)
        {
            String TempVal = JTF.getText();
            if(TempVal.equals(""))
            {
                System.out.println(FieldDesc+" RadioButton Selected. But the value is selected as empty. Please add " + FieldDesc);
                isSuccess=false;
                //MandatoryFieldMissingMessageBox();
            }
            else
            {
                if(!NumericValueCheck(TempVal))
                {
                    System.out.println(FieldDesc+" RadioButton Selected. Non-Numeric Value Found. Please add " + FieldDesc + " in numeric");
                    isSuccess=false;
                    //MandatoryFieldMissingMessageBox();
                }
                else
                {
                    System.out.println(FieldDesc+" RadioButton Selected. Value Looks Fine");
                    isSuccess=true;
                }
            }
        }
        else
        {
            System.out.println(FieldDesc+" RadioButton Not Selected.");
            isSuccess=true;
        }
        return isSuccess;
    }

    public void TypeOfRecStartOptions() {

        if(IsRadioButtonSelected(JRB_Image))
        {
            //If Image Choosen
            StartImageCaptureButton();
        }
        else
        {
            //If Video Choosen
            ScreenVideoRecordAreaMain();
        }

    }

    public void TypeOfRecStopOptions() {

        if(IsRadioButtonSelected(JRB_Image))
        {
            //If Image Choosen
            StopImageCaptureButton();
        }
        else
        {
            //If Video Choosen
            StopVideoRecording();
        }

    }

    public void EnableDisableFirstLoad()
    {
        if(IsRadioButtonSelected(JRB_Image))
        {
            //If Image Choosen
            //JCB_DelayStart.setEnabled(false);
            JTF_DSValue.setEnabled(false);

            JCB_MaxVRec.setEnabled(false);
            JTF_MaxVRecVal.setEnabled(false);

            JTF_VFrameRateVal.setEnabled(false);

            JTF_ImgTFVal.setEnabled(true);
        }
        else
        {
            //If Video Choosen
            JTF_ImgTFVal.setEnabled(false);

            //JCB_DelayStart.setEnabled(true);
            //JTF_DSValue.setEnabled(true);
            JTF_DSValue.setEnabled(false);

            JCB_MaxVRec.setEnabled(true);
            JTF_MaxVRecVal.setEnabled(true);

            JTF_VFrameRateVal.setEnabled(true);

        }

        JB_StopRec.setEnabled(false);
    }

    public void EnableDisableStartRecordingButtons()
    {
        JB_StartRec.setEnabled(false);
        JB_StopRec.setEnabled(true);
        JB_ResetRec.setEnabled(false);
    }

    public void EnableDisableStopRecordingButtons()
    {
        JB_StartRec.setEnabled(true);
        JB_StopRec.setEnabled(false);
        JB_ResetRec.setEnabled(true);
    }

    public boolean MandatoryFieldChecks() {

        boolean MandCheckValue=false;

        boolean isDelay = false;
        boolean isMaxRec = false;
        boolean isImg = false;
        boolean isVid = false;
        boolean isFilePre = false;
        boolean isFilePath = false;

        //Delay Start Check Box and Value
        isDelay = CheckBoxAndValueValidation(JCB_DelayStart,JTF_DSValue,"Delay Start");

        //Max Video Rec Check Box and Value
        isMaxRec = CheckBoxAndValueValidation(JCB_MaxVRec,JTF_MaxVRecVal,"Maximum Recording Time");

        //Recording Type

        //Image Frame Rate
        isImg = RadioButtonAndValueValidation(JRB_Image,JTF_ImgTFVal,"Image & Time Frame");

        //Video Frame Rate
        isVid = RadioButtonAndValueValidation(JRB_Video,JTF_VFrameRateVal,"Video & Frame Rate");


        //FileName Prefix
        if(JTF_RecordFilePrefixVal.getText().contentEquals(""))
        {
            System.out.println("Filename Prefix not provided. Please update and rerun");
            isFilePre = false;
        }
        else
        {
            System.out.println("Filename Prefix provided. User should be good with this validation");
            isFilePre = true;
        }

        //File Path Existance
        isFilePath = FilePathExistance(JTA_LocBrowseVal.getText());

        if(isDelay && isMaxRec && isImg && isVid && isFilePre && isFilePath)
        {
            MandCheckValue=true;
        }
        else
        {
            MandCheckValue=false;
        }

        return MandCheckValue;

    }

    public void ClickBrowsePath(ActionEvent e)
    {
        //JB_Browse.addActionListener(new ActionListener() {
            //public void actionPerformed(ActionEvent e) {
                //FileBrowse(e,JTA_LocBrowseVal);
            //}
        //} );

        FileBrowse(e,JTA_LocBrowseVal);
    }

    public void FileBrowse(ActionEvent evt,JTextArea JTA_LocBrowseVal){
        // if the user presses the save button show the save dialog
        String com = evt.getActionCommand();

        if (com.equals("save")) {
            // create an object of JFileChooser class
            JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

            // set the selection mode to directories only
            j.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            // invoke the showsSaveDialog function to show the save dialog
            int r = j.showSaveDialog(null);

            if (r == JFileChooser.APPROVE_OPTION) {
                // set the label to the path of the selected directory
                JTA_LocBrowseVal.setText(j.getSelectedFile().getAbsolutePath());
            }
            // if the user cancelled the operation
            else {
                JTA_LocBrowseVal.setText(BrowseCancel);
            }
        }
        // if the user presses the open dialog show the open dialog
        else {
            // create an object of JFileChooser class
            JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

            // set the selection mode to directories only
            j.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            // invoke the showsOpenDialog function to show the save dialog
            int r = j.showOpenDialog(null);

            if (r == JFileChooser.APPROVE_OPTION) {
                // set the label to the path of the selected directory
                JTA_LocBrowseVal.setText(j.getSelectedFile().getAbsolutePath());
            }
            // if the user cancelled the operation
            else {
                JTA_LocBrowseVal.setText(BrowseCancel);
            }
        }
    }

    public String TimeForFileGetter() {
        String TimeFile="";
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd hh mm ss a");
            Calendar now = Calendar.getInstance();
            TimeFile=formatter.format(now.getTime());
            TimeFile = "_"+TimeFile.replaceAll(" ","_");
            return TimeFile;
        } catch (Exception e) {
            e.printStackTrace();
            return TimeFile;
        }
    }

    public void StartImageCaptureButton() {
        //JB_StartRec.addActionListener(new ActionListener() {
            //public void actionPerformed(ActionEvent e) {
                try {
                    FilePath = JTA_LocBrowseVal.getText();
                    FilePath = FilePath + "\\";
                    timeframe = JTF_ImgTFVal.getText();
                    String FileName = JTF_RecordFilePrefixVal.getText();
                    if(!FilePath.contentEquals("") && !timeframe.contentEquals("") && !FilePath.contains("Browse Option Cancelled. Please retry if you want!!!"))
                    {
                        Path = FilePath;
                        int timeframeint=Integer.valueOf(timeframe)*1000;
                        IsImageCapture = true;
                        StartImageCaptureMain(Path,timeframeint,FileName);
                    }
                    else
                    {
                        IsImageCapture = false;
                        JOptionPane.showMessageDialog(null,"File Path Or Timframe has some error. Please recheck and run","Mandatory Field Error",JOptionPane.ERROR_MESSAGE);
                    }

                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            //}
        //});
    }

    public void StopImageCaptureButton() {
        //JB_StopRec.addActionListener(new ActionListener() {
            //@SuppressWarnings("static-access")
            //public void actionPerformed(ActionEvent e) {
                IsImageCapture = false;
                JOptionPane.showMessageDialog(null,"Image Capturing Finished","Process Completion",JOptionPane.INFORMATION_MESSAGE);
            //}
       // });
    }

    public void robo(String Path, String FileName) throws Exception
    {
        Calendar now = Calendar.getInstance();
        Robot robot = new Robot();
        BufferedImage screenShot = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(screenShot, ImageFormat.toUpperCase(), new File(Path + FileName + TimeForFileGetter() + "." +ImageFormat));
        System.out.println(formatter.format(now.getTime()));
    }

    @SuppressWarnings("static-access")
    public void StartImageCaptureMain(String Path,int timef, String FileName) throws Exception
    {
        new Thread(new Runnable() {
            @Override
            public void run() {
                //ImageCapture obj = new ImageCapture();
                String isDSValue = CheckBoxMaxVideoRecOption(JCB_DelayStart,JTF_DSValue,"Delay Record Time");

                if(isDSValue.contentEquals(""))
                {

                }
                else
                {
                    try {
                        Thread.sleep(Integer.parseInt((isDSValue))* 1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }

                while(IsImageCapture)
                {
                    try
                    {
                        robo(Path,FileName);
                        Thread.sleep(timef);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();


    }


    public void FontSetting(String FontName, int FontSize,JFrame JF) {
        try {
            //Set FontName,Property and Size
            FontName= "Segoe UI";
            FontSize= 12;
            int FontStyle = Font.PLAIN; //0 for Plain, 1 for BOLD, 2 For Italic, Others are there
            Font font = new Font(FontName, FontStyle, FontSize);
            JF.setFont(font);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //This function can be used later - Now it is not in scope
    public void ImageIndivudualCapt(String Path, String FileName) throws Exception
    {
        try {
            Calendar now = Calendar.getInstance();
            Thread.sleep(120);
            Robot r = new Robot();
            // It saves screenshot to desired path
            String Path1 = Path + FileName + TimeForFileGetter() + "." + ImageFormat;

            // Used to get ScreenSize and capture image
            Rectangle capture = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage Image = r.createScreenCapture(capture);
            ImageIO.write(Image, ImageFormat, new File(Path1));
            System.out.println("Screenshot Saved");
        }
        catch (AWTException | IOException | InterruptedException ex) {
            System.out.println(ex);
        }
    }

    //Not Applicable now
    public void IndivudualImageCaptureButton() {
        //For Indivudual Image capture
        JButton B3 = new JButton();
        B3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    FilePath = JTA_LocBrowseVal.getText();
                    FilePath = FilePath + "\\";
                    String FileName = JTF_RecordFilePrefixVal.getText();
                    if(!FilePath.contentEquals(""))
                    {
                        Path = FilePath;
                        StartIndivudualImage(Path,FileName);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"File Path Or Timframe has some error. Please recheck and run","Mandatory Field Error",JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
    }

    //Not Applicable now
    public void StartIndivudualImage(String Path,String FileName) throws Exception
    {
        ImageIndivudualCapt(Path,FileName);
    }

    //Not Applicable now
    public void ScreenSizeDisplay()
    {
        //Call To get ScreenSize
        ScreenSize = ScreenSizeCalc();

        ScreenWidth = Integer.parseInt(ScreenSize.split("\\|")[0]);
        ScreenHeight = Integer.parseInt(ScreenSize.split("\\|")[1]);

        ScreenWidth = 1920;
        ScreenHeight = 1080;

        System.out.println("Automatic Check for Screen Dimensions");
        System.out.println("#####################################");
        System.out.println("Screen Width    : " + ScreenWidth);
        System.out.println("Screen Height   : " + ScreenHeight);
    }

    //Not Applicable now
    public String ScreenSizeCalc()
    {
        String ScreenSize="";
        String Delim1 = "|";
        try {
            // Get the screen size
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

            // Get the width and height
            int width = screenSize.width;
            int height = screenSize.height;

            // Print the screen size
            //System.out.println("Screen Width : " + width);
            //System.out.println("Screen Height : " + height);

            ScreenSize = width + Delim1 + height;

            return ScreenSize;
        }
        catch (Exception e) {
            System.out.println(e);
            //By Default Setting 1920x1080
            ScreenSize = 1920 + Delim1 + 1080;
            return ScreenSize;
        }

    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
