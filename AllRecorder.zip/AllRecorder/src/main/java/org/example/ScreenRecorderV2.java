package org.example;

import com.xuggle.mediatool.IMediaWriter;
import com.xuggle.mediatool.ToolFactory;
import com.xuggle.xuggler.ICodec;
import com.xuggle.xuggler.IPixelFormat;
import com.xuggle.xuggler.IRational;

import javax.sound.sampled.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class ScreenRecorderV2 {
    private static final double FRAME_RATE = 30;
    private static final int SECONDS_TO_RUN_FOR = 10;
    private static final String OUTPUT_FILE = "output.mp4";

    public static void main(String[] args) throws AWTException, IOException, LineUnavailableException {
        Dimension screenBounds = Toolkit.getDefaultToolkit().getScreenSize();

        IMediaWriter writer = ToolFactory.makeWriter(OUTPUT_FILE);
        writer.addVideoStream(0, 0, ICodec.ID.CODEC_ID_H264, IRational.make(30, 1), screenBounds.width, screenBounds.height);
        writer.addAudioStream(1, 0, 2, 44100);

        long startTime = System.currentTimeMillis();

        // Setup audio capture
        AudioFormat audioFormat = new AudioFormat(44100, 16, 2, true, true);
        TargetDataLine line = AudioSystem.getTargetDataLine(audioFormat);
        line.open(audioFormat);
        line.start();

        byte[] audioBuffer = new byte[line.getBufferSize() / 5];
        int audioBytesRead;

        while (System.currentTimeMillis() - startTime < SECONDS_TO_RUN_FOR * 1000) {
            BufferedImage screen = new Robot().createScreenCapture(new Rectangle(screenBounds));
            BufferedImage bgrScreen = convertToType(screen, BufferedImage.TYPE_3BYTE_BGR);

            writer.encodeVideo(0, bgrScreen, System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

            audioBytesRead = line.read(audioBuffer, 0, audioBuffer.length);
            //writer.encodeAudio(1, audioBuffer, audioBytesRead);

            try {
                Thread.sleep((long) (1000 / FRAME_RATE));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        writer.close();
        line.close();
    }

    private static BufferedImage convertToType(BufferedImage sourceImage, int targetType) {
        BufferedImage image;

        if (sourceImage.getType() == targetType) {
            image = sourceImage;
        } else {
            image = new BufferedImage(sourceImage.getWidth(),
                    sourceImage.getHeight(), targetType);
            image.getGraphics().drawImage(sourceImage, 0, 0, null);
        }

        return image;
    }
}
