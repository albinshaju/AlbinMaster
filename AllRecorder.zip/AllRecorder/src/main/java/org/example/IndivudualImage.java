package org.example;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.io.File;
import javax.imageio.ImageIO;

public class IndivudualImage {

    public static final long serialVersionUID = 1L;
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd hh mm ss a");

    public static void main(String[] args)
    {


    }

    public void IndCapt(String Path) throws Exception
    {
        try {
            Calendar now = Calendar.getInstance();
            Thread.sleep(120);
            Robot r = new Robot();
            // It saves screenshot to desired path
            String Path1 = Path+formatter.format(now.getTime())+".jpg";
            // Used to get ScreenSize and capture image
            Rectangle capture = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage Image = r.createScreenCapture(capture);
            ImageIO.write(Image, "jpg", new File(Path1));
            System.out.println("Screenshot Saved");
        }
        catch (AWTException | IOException | InterruptedException ex) {
            System.out.println(ex);
        }
    }
}


